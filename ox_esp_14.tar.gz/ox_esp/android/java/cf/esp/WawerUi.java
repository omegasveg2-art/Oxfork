package cf.esp;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.Locale;

/** Wawer menu: dark rounded window, sidebar tabs, cards with toggles / sliders / choices. Built from plain views. */
final class WawerUi {
    interface Host { void changed(); void close(); void unload(); }

    static final int BG = 0xF2101215, CARD = 0xFF171A1F, EDGE = 0xFF262B32, ACCENT = 0xFF5AB0FF, TEXT = 0xFFE8EAED, DIM = 0xFF8B929B, OFF = 0xFF3A3F47;
    static final String[] TABS = {"Silent", "ESP", "Visuals", "Info", "Config"};

    final LinearLayout root;
    final View header;
    private final Context c;
    private final Host h;
    private final LinearLayout sidebar;
    private final ScrollView scroll;
    private int tab = 0, flip;
    private TextView statusV;
    private LinearLayout colA, colB;

    WawerUi(Context ctx, Host host) {
        c = ctx; h = host;
        root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(rounded(BG, EDGE, 16, 1));
        root.setPadding(dp(12), dp(10), dp(12), dp(12));

        LinearLayout head = new LinearLayout(c);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("Wawer OX", 20, TEXT);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setLetterSpacing(0.04f);
        head.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView close = text("✕", 14, DIM);                      // square close button
        close.setGravity(Gravity.CENTER);
        close.setBackground(rounded(0xFF1D2127, EDGE, 8, 1));
        close.setOnClickListener(v -> h.close());
        head.addView(close, new LinearLayout.LayoutParams(dp(30), dp(30)));
        header = head;
        statusV = text("", 10.5f, DIM);
        statusV.setPadding(dp(2), dp(2), 0, dp(6));
        root.addView(head, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(statusV, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout body = new LinearLayout(c);
        body.setOrientation(LinearLayout.HORIZONTAL);
        sidebar = new LinearLayout(c);
        sidebar.setOrientation(LinearLayout.VERTICAL);
        sidebar.setPadding(0, dp(10), dp(10), 0);
        ScrollView sideScroll = new ScrollView(c);
        sideScroll.setVerticalScrollBarEnabled(false);
        sideScroll.addView(sidebar);
        body.addView(sideScroll, new LinearLayout.LayoutParams(dp(112), ViewGroup.LayoutParams.MATCH_PARENT));
        scroll = new ScrollView(c);
        scroll.setVerticalScrollBarEnabled(false);
        body.addView(scroll, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        root.addView(body, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        select(tab);
    }

    // ------------------------------------------------------------------ helpers
    private int dp(float v) { return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable rounded(int fill, int stroke, float radiusDp, float strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) g.setStroke(Math.max(1, dp(strokeDp)), stroke);
        return g;
    }

    private TextView text(String t, float sp, int col) {
        TextView v = new TextView(c);
        v.setText(t);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        v.setTextColor(col);
        v.setIncludeFontPadding(false);
        return v;
    }

    // ------------------------------------------------------------------ tabs
    private void select(int i) {
        tab = i;
        sidebar.removeAllViews();
        for (int t = 0; t < TABS.length; t++) {
            final int idx = t;
            LinearLayout item = new LinearLayout(c);
            item.setOrientation(LinearLayout.HORIZONTAL);
            item.setGravity(Gravity.CENTER_VERTICAL);
            item.setPadding(dp(8), 0, dp(8), 0);
            boolean on = t == tab;
            if (on) item.setBackground(rounded(0xFF1C2127, 0, 9, 0));
            View bar = new View(c);
            bar.setBackground(rounded(on ? ACCENT : 0, 0, 2, 0));
            item.addView(bar, new LinearLayout.LayoutParams(dp(3), dp(16)));
            TextView tv = text(TABS[t], 13, on ? TEXT : DIM);
            tv.setPadding(dp(10), 0, 0, 0);
            item.addView(tv);
            item.setOnClickListener(v -> select(idx));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34));
            lp.bottomMargin = dp(2);
            sidebar.addView(item, lp);
        }
        rebuild();
    }

    private void rebuild() {
        scroll.removeAllViews();
        LinearLayout cols = new LinearLayout(c);
        cols.setOrientation(LinearLayout.HORIZONTAL);
        colA = new LinearLayout(c); colA.setOrientation(LinearLayout.VERTICAL);
        colB = new LinearLayout(c); colB.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams la = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        la.rightMargin = dp(5);
        LinearLayout.LayoutParams lb = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lb.leftMargin = dp(5);
        cols.addView(colA, la);
        cols.addView(colB, lb);
        scroll.addView(cols);
        flip = 0;
        Snap sn = Model.snap;
        statusV.setText(sn.ok ? "core ok  \u00b7  " + sn.players.length + " players" : "core: " + sn.status);
        statusV.setTextColor(sn.ok ? 0xFF4ADE80 : 0xFFFFB86B);
        switch (tab) {
            case 0: tabSilent(); break;
            case 1: tabPlayers(); break;
            case 2: tabVisuals(); break;
            case 3: tabMisc(); break;
            default: tabConfig();
        }
    }

    private LinearLayout card(String title) {
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(rounded(CARD, EDGE, 12, 1));
        card.setPadding(dp(4), dp(8), dp(4), dp(6));
        TextView t = text(title, 11, DIM);
        t.setPadding(dp(10), 0, dp(10), dp(4));
        card.addView(t);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(10);
        ((flip++ % 2 == 0) ? colA : colB).addView(card, lp);
        return card;
    }

    private LinearLayout row(LinearLayout card, String label, View right) {
        LinearLayout r = new LinearLayout(c);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(10), dp(6), dp(10), dp(6));
        r.addView(text(label, 12.5f, TEXT), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        r.addView(right);
        card.addView(r, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return r;
    }

    private static final class Toggle extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rf = new RectF();
        boolean on;
        Toggle(Context c, boolean on) { super(c); this.on = on; }
        @Override protected void onMeasure(int w, int hh) {
            float d = getResources().getDisplayMetrics().density;
            setMeasuredDimension((int) (38 * d), (int) (21 * d));
        }
        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), hh = getHeight();
            p.setColor(on ? ACCENT : OFF);
            rf.set(0, 0, w, hh);
            cv.drawRoundRect(rf, hh / 2, hh / 2, p);
            p.setColor(Color.WHITE);
            cv.drawCircle(on ? w - hh / 2 : hh / 2, hh / 2, hh / 2 - 2.5f * getResources().getDisplayMetrics().density, p);
        }
    }

    private void toggle(LinearLayout card, String label, String key) {
        Toggle t = new Toggle(c, Cfg.b(key));
        View r = row(card, label, t);
        View.OnClickListener l = v -> { t.on = !t.on; t.invalidate(); Cfg.set(key, t.on ? 1f : 0f); h.changed(); };
        r.setOnClickListener(l);
        t.setOnClickListener(l);
    }

    private void slider(LinearLayout card, String label, String key, float min, float max) {
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10), dp(6), dp(10), dp(2));
        LinearLayout top = new LinearLayout(c);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.addView(text(label, 12.5f, TEXT), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final String fmt = (max - min) >= 50f ? "%.0f" : (max - min) >= 5f ? "%.1f" : "%.2f";
        TextView val = text(String.format(Locale.US, fmt, Cfg.f(key)), 12, ACCENT);
        top.addView(val);
        box.addView(top);
        SeekBar sb = new SeekBar(c);
        sb.setMax(1000);
        sb.setProgress(Math.round((Cfg.f(key) - min) / (max - min) * 1000f));
        sb.setProgressTintList(ColorStateList.valueOf(ACCENT));
        sb.setThumbTintList(ColorStateList.valueOf(Color.WHITE));
        sb.setProgressBackgroundTintList(ColorStateList.valueOf(OFF));
        sb.setPadding(dp(8), dp(4), dp(8), dp(4));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int pr, boolean user) {
                float v = min + (max - min) * pr / 1000f;
                Cfg.set(key, v);
                val.setText(String.format(Locale.US, fmt, v));
                if (user) h.changed();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        box.addView(sb, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(26)));
        card.addView(box, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private void choice(LinearLayout card, String label, String key, String[] opts) {
        TextView v = text(opts[Math.max(0, Math.min(opts.length - 1, Cfg.i(key)))] + "  ▾", 12, TEXT);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(10), dp(5), dp(10), dp(5));
        v.setBackground(rounded(0xFF1D2127, EDGE, 8, 1));
        View.OnClickListener l = x -> {
            int n = (Cfg.i(key) + 1) % opts.length;
            Cfg.set(key, n);
            v.setText(opts[n] + "  ▾");
            h.changed();
        };
        v.setOnClickListener(l);
        row(card, label, v).setOnClickListener(l);
    }

    private void color(LinearLayout card, String label, String key, int[] palette) {
        View sw = new View(c);
        sw.setBackground(rounded(palette[Math.max(0, Math.min(palette.length - 1, Cfg.i(key)))], Color.WHITE, 7, 1));
        View.OnClickListener l = x -> {
            int n = (Cfg.i(key) + 1) % palette.length;
            Cfg.set(key, n);
            sw.setBackground(rounded(palette[n], Color.WHITE, 7, 1));
            h.changed();
        };
        sw.setOnClickListener(l);
        LinearLayout r = row(card, label, sw);
        sw.setLayoutParams(new LinearLayout.LayoutParams(dp(24), dp(24)));
        r.setOnClickListener(l);
    }

    private void button(LinearLayout card, String label, Runnable run) {
        TextView b = text(label, 13, TEXT);
        b.setGravity(Gravity.CENTER);
        b.setBackground(rounded(0xFF1D2127, EDGE, 9, 1));
        b.setOnClickListener(v -> run.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34));
        lp.setMargins(dp(8), dp(4), dp(8), dp(4));
        card.addView(b, lp);
    }

    private void note(LinearLayout card, String t) {
        TextView v = text(t, 11, DIM);
        v.setPadding(dp(10), dp(2), dp(10), dp(4));
        card.addView(v);
    }

    // ------------------------------------------------------------------ tab contents
    private static final String[] KEYS = {"Always", "Vol Down", "Vol Up"};

    private void tabSilent() {
        LinearLayout a = card("SILENT AIM");
        toggle(a, "Enable", "sil");
        choice(a, "Target", "sbone", new String[]{"Head", "Body", "Legs"});
        slider(a, "FOV (deg)", "sfov", 1f, 25f);
        slider(a, "Max distance", "smaxd", 20f, 500f);
        toggle(a, "Show FOV circle", "showFov");
        note(a, "Redirects the next shot to the closest target inside the FOV circle at the chosen bone. Off-target shots behave normally.");
        LinearLayout w = card("WEAPON");
        toggle(w, "No recoil", "norecoil");
        note(w, "Zeroes the weapon's own accumulated recoil state every tick.");
        LinearLayout st = card("STATUS");
        Snap s = Model.snap;
        String si = "?";
        int i = s.info.indexOf("sil=");
        if (i >= 0) si = s.info.substring(i + 4);
        note(st, "silent: " + si);
        note(st, "Hit registration may still be checked by the server; this only changes what the client aims at.");
    }

    private void tabPlayers() {
        LinearLayout b = card("BOX");
        toggle(b, "ESP", "esp");
        choice(b, "Style", "boxStyle", new String[]{"Full", "Corner"});
        toggle(b, "Chams-style fill", "chams");
        toggle(b, "Glow", "glow");
        toggle(b, "Head dot", "headDot");
        LinearLayout i = card("INFO");
        toggle(i, "Health bar", "health");
        toggle(i, "HP text", "hpText");
        toggle(i, "Name", "name");
        toggle(i, "Distance", "dist");
        toggle(i, "Snaplines", "snap");
        toggle(i, "Off-screen arrows", "offscreen");
        LinearLayout col = card("COLORS");
        color(col, "Enemy", "enemyCol", Cfg.ENEMY);
        color(col, "Team", "teamCol", Cfg.TEAM);
    }

    private void tabVisuals() {
        LinearLayout wd = card("WORLD");
        toggle(wd, "Enemy counter pill", "hud");
        LinearLayout o = card("OVERLAY");
        toggle(o, "Radar", "radar");
        slider(o, "Radar range", "radarRange", 10f, 120f);
        toggle(o, "Crosshair dot", "crosshair");
        slider(o, "Max distance", "maxDist", 20f, 800f);
        LinearLayout s = card("SYNC");
        slider(s, "Display sync (ms)", "lat", -100f, 100f);
        slider(s, "Camera FOV", "camFov", 40f, 110f);
        slider(s, "FOV scale", "fovScale", 0.7f, 1.3f);
        slider(s, "Box height", "boxH", 1.2f, 2.5f);
        note(s, "Camera FOV is the game camera's vertical FOV (the core cannot read it): if boxes sit too far from the centre when you look around, adjust it until they stick to the players. Boxes run AHEAD of the view when you turn: move Display sync lower (negative). Boxes lag behind: raise it. Off-centre: FOV scale / horizontal.");
    }

    private void tabMisc() {
        LinearLayout a = card("STATUS");
        Snap s = Model.snap;
        note(a, "core: " + (s.ok ? "ok" : s.status));
        note(a, "players: " + s.players.length + "   fov: " + s.fov);
        note(a, "package: " + Cfg.pkg);
        if (!s.info.isEmpty()) note(a, s.info);
        LinearLayout b = card("ABOUT");
        note(b, "Wawer OX for Oxide: Survival Island 1.16.11978. The chams-style fill is drawn on top of the screen; the real models are not recoloured.");
    }

    private void tabConfig() {
        LinearLayout a = card("CONFIG");
        button(a, "Save", () -> { Cfg.save(c); h.changed(); });
        button(a, "Load", () -> { Cfg.load(c); h.changed(); rebuild(); });
        button(a, "Reset to defaults", () -> { Cfg.reset(); h.changed(); rebuild(); });
        button(a, "Unload", h::unload);
    }
}
